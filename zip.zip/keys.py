# ─────────────────────────────────────────────────────────
#  DragonGP — API Keys  (auto-manages user-donated keys)
# ─────────────────────────────────────────────────────────
import json, os

_DYNAMIC_FILE = os.path.join(os.path.dirname(__file__), "user_keys.json")

def _load_dynamic():
    if os.path.exists(_DYNAMIC_FILE):
        try:
            return json.load(open(_DYNAMIC_FILE))
        except:
            pass
    return {}

_BAD = {"","your-gemini-key-1","your-gemini-key-2","your-groq-key-1",
        "your-groq-key-2","your-cohere-key-1","your-cohere-key-2"}

def _real(keys):
    return [k for k in keys if k.strip() and k.strip() not in _BAD]

_STATIC = { 
  # "gemini":    ["AIzaSyDOsJc9fwC2bIkQEsbfhb-cwLWy2MoJyIY"
   #              "AIzaSyAIAvQ46hIMHVjq39ai-Jd3N-0cXdbp-IM"
                 
  #],
    "groq":      ["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"],
    "cohere":    ["cXRJRBvocOTtj6Nzi2VSiXL6UGx9pWpAbVmQURpf"],
    #"mistral":   ["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"],# its of groq
    #"together":["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"],#its groq.
    
    "openrouter":[
        "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",
        "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",
        "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"
    ], # openrouter
    #"cloudflare":["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"],#openrouter
    #"cerebras":["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"], #openrouter
    #"sambanova":[], 
}

CLOUDFLARE_ACCOUNT_ID = ""

def _merged(name):
    return _real(_STATIC.get(name,[]) + _load_dynamic().get(name,[]))

GEMINI_KEYS     = _merged("gemini")
GROQ_KEYS       = _merged("groq")
COHERE_KEYS     = _merged("cohere")
MISTRAL_KEYS    = _merged("mistral")
TOGETHER_KEYS   = _merged("together")
CLOUDFLARE_KEYS = _merged("cloudflare")
CEREBRAS_KEYS   = _merged("cerebras")
SAMBANOVA_KEYS  = _merged("sambanova")
OPENROUTER_KEYS = _merged("openrouter")

def add_user_key(provider: str, key: str) -> bool:
    key = key.strip()
    if not key or len(key) < 10:
        return False
    dyn = _load_dynamic()
    bucket = dyn.setdefault(provider.lower(), [])
    if key in bucket:
        return False
    bucket.append(key)
    json.dump(dyn, open(_DYNAMIC_FILE,"w"), indent=2)
    import sys
    mod = sys.modules[__name__]
    for attr, nm in [("GEMINI_KEYS","gemini"),("GROQ_KEYS","groq"),("COHERE_KEYS","cohere"),
                     ("MISTRAL_KEYS","mistral"),("TOGETHER_KEYS","together"),
                     ("CLOUDFLARE_KEYS","cloudflare"),("CEREBRAS_KEYS","cerebras"),
                     ("SAMBANOVA_KEYS","sambanova"),("OPENROUTER_KEYS","openrouter")]:
        setattr(mod, attr, _merged(nm))
    return True

def get_key_counts():
    return {name: len(_merged(name)) for name in _STATIC}
